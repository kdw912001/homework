package board.run;

import board.view.BoardMenu;

public class RunBoard {

	public static void main(String[] args) {
		BoardMenu test = new BoardMenu();
		test.mainMenu();

	}

}
