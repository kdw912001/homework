package ncs4.test1;
import java.util.*;
public class Decending implements Comparator<Integer>{
	public int compare(Integer o1, Integer o2) {
		return o2.compareTo(o1);
	}
	
	
}
