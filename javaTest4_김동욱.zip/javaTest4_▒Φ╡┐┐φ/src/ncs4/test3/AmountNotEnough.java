package ncs4.test3;

public class AmountNotEnough extends Exception{
	public AmountNotEnough(String message) {
		super(message);
	}
}
